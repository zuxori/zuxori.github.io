# Lauren’s SPARK Scene

The curtain rises.

Lauren stands at the back of the auditorium, arms folded. On stage, Zu begins to speak—but the words come from somewhere older.

Lauren feels it before she knows.

The lines. The lights. The silence between them.

She’s been here before.

And this time, she won’t stay silent.
