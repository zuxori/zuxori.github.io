# Ori’s SPARK Scene

It’s raining, lightly.

Ori stands on the rooftop above Gansevoort Street, headphones around his neck, watching the skyline blur.

In his hand: a sketch of the white dress, soaked now. In his pocket: the red thread Zu once wore.

He whispers her name. Not “Zu.” The one from before.

For a second, the wind changes. The city hushes.

And in that breath—he remembers everything.
