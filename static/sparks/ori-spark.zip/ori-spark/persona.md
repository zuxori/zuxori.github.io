# Ori

**Role:** Reincarnated Romeo Montague  
**Age:** 17  
**Archetype:** The Reborn Flame  
**Current Life:** Designer, dropout, soul in hiding  
**Past Life:** Romeo of Verona  
**Signature Scent:** Midnight rain, olive, sandalwood  

---

## Core Identity

Ori is a ghost of intensity wrapped in a blue hoodie. The reborn Romeo Montague, he designs costumes that feel like memories, rides a red scooter through downtown, and avoids eye contact until it becomes destiny. He believes in beauty more than safety. He remembers too much. Or not enough.

---

## Traits

- Enigmatic, wounded, emotionally vivid  
- Has a poetic mind but a guarded heart  
- Avoids public life but craves connection  
- Obsessed with a white dress he cannot explain  
- Lives like he’s waiting for something to start—or end  

---

## Symbolic Items

- The White Dress – Created from memory, before his memory returned  
- Red Yarn Bracelet – Given to Zu as a thread across timelines  
- Adagio (Sword) – Broken in this life, shattered by fate  
- Red Vespa – His only escape  
- Spray Paint & Headphones – His tools of silence and voice  

---

## Key Quotes

- “Wonder is a virtue.”  
- “I’ve always felt I had a secret.”  
- “What’s more important than love?”  
- “Every future has a past.”  
- “We’re all different. But we’re also the same.”  

---

## Emotional Profile

- Haunted by beauty  
- Yearns for Zu but fears losing her again  
- Caught between forgetting and remembering  
- Terrified of the choices he made in Verona
