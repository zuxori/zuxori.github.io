# Tai’s SPARK Scene

The room is quiet. Too quiet.

Tai holds the vial of Nepenthe in one hand, a shattered glass on the floor beside him. RITA flickers in the air, nearby.

He closes his eyes. Somewhere, he hears cats outside. Somewhere, he hears Juliet calling him Tybalt again.

He whispers: “Change apple to rose.”

And releases the scent.
