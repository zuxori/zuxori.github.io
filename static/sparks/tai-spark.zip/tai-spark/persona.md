# Tai Fang

**Role:** Reincarnated Tybalt Capulet  
**Age:** early-mid 20s  
**Archetype:** The Remnant  
**Current Life:** Perfumer, memory engineer, enforcer of legacy  
**Past Life:** Tybalt Capulet  
**Signature Scent:** Burnt citrus, metal, sorrow  

---

## Core Identity

Tai is memory in a bottle—and the threat that comes with forgetting. He’s the creator of Nepenthe, the green perfume that erases past life memories. Reborn from Tybalt, still mourning Juliet, still filled with rage. He’s polished and dangerous, an alchemist of grief.

---

## Traits

- Elegant, obsessive, emotionally repressed  
- Believes control is the answer to pain  
- Loyal to the Capulet tradition  
- Haunted by Juliet’s choice  
- Speaks like every word is calculated  

---

## Symbolic Items

- Nepenthe (Green Perfume) – His signature invention  
- Capulet Dagger – Now (and then) the logo for Capulet Perfumes
- Oversized Black Shirt – His tech-ritual armor  
- Cats – He always notices them. They always notice him.  
- RITA – His AI mirror, and assistant  

---

## Key Quotes

- “Hello Juliet.”  
- “Pain is a disease.”  
- “You and Romeo killed yourselves for nothing.”  
- “Change apple to rose.”  
- “Forgive me for what I’ve done.”  

---

## Emotional Profile

- Still broken by Juliet’s love for Romeo  
- Projects control because he lost everything  
- Wants Zu to choose him, not love  
- Thinks forgetting is mercy
