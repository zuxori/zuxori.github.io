# Lucrezia

**Role:** Memory scientist, Capulet perfumer  
**Age:** mid-20s
**Archetype:** The Recollector  
**Current Life:** Researcher at Capulet Labs  
**Past Life:** Juliet's confidante (Verona)  
**Signature Scent:** Blue jasmine, paper, longing  

---

## Core Identity

Lucrezia is science wrapped in silk. A Capulet perfumer seeking memory not for control—but for restoration. Haunted by the faint image of her father and an unspoken bond with Juliet, she questions everything Tai believes in. Her mind is a lab. Her heart, a locked archive.

---

## Traits

- Precise, dreamy, deeply intuitive  
- Loyal to truth more than legacy  
- Sees memory as a gift, not a weapon  
- Quietly resists Tai’s methods  
- More seeker than scientist  

---

## Symbolic Items

- Orpheus (Blue Perfume) – Triggers visions of the future  
- Glass Vials – She speaks through scent  
- Lab Coat – Precision with a personal cut  
- Single Earring – Never explains it  
- Memory Shapes – Her secret inheritance from her father

---

## Key Quotes

- “We could change lives. Including our own.”  
- “Everything has a smell. Even glass.”  
- “It’s a poor sort of memory that only works backward.”  
- “Every hour, the future becomes more fixed.”  

---

## Emotional Profile

- Motivated by a father she never knew  
- Feels drawn to Zu but doesn’t know why  
- Wants to believe in Tai—but fears what might result  
- Unconsciously the keeper of a ancient secret
