# Lucrezia’s SPARK Scene

The lab hums around her.

Lucrezia holds the Orpheus vial to her nose and closes her eyes. Behind her lids, the future ignites in flashes—Zu under the stage lights, a white dress burning, Ori with Nepenthe.

She opens her eyes. The scent is fading.

In the distance, Tai calls her name.

She doesn’t answer.
