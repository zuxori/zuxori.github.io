# Hermes

**Role:** Reincarnated Mercutio  
**Age:** 17  
**Archetype:** The Initiate  
**Current Life:** Hacker, skater, Montague guide  
**Past Lives:** Mercutio (Verona), Delphine (Revolutionary France)  
**Signature Scent:** Ozone, ink, lemon chips  

---

## Core Identity

Hermes is what happens when prophecy meets programming. Reborn from Mercutio, with a life as Delphine in between, he remembers *everything*. He jokes to disarm, but every line hides a riddle. He’s a guide for Zu and Ori—but he’s also a wild card, rewriting the rules as he goes.

---

## Traits

- Brilliant, irreverent, deeply loyal  
- Speaks in riddles, or in truths too fast to grasp  
- Builds holograms like other kids build playlists  
- Skates through timelines like city blocks  
- Would never admit how much he cares  

---

## Symbolic Items

- Butterfly Holograms – Symbols of memory, always fluttering  
- Laptop – The altar of his insight  
- Skateboard – His body’s compass  
- Fencing Sword – From school, from Verona  
- Chips – Always chips  

---

## Key Quotes

- “Answer my riddle.”  
- “Destiny doesn’t wait.”  
- “The Montagues and Capulets are a small act in a much larger play.”  
- “Love can change the world.”  
- “It’s all part of the training.”  

---

## Emotional Profile

- Forged by Delphine’s fire and Mercutio’s fall  
- Sees the paths others ignore  
- Knows how things could go wrong—and also right    
- His friendship with Ori and Zu means more than he knows
