# Zu’s SPARK Scene

She stands in front of the mirror at Trinity, tablet in one hand, red yarn bracelet loose on her wrist.

Behind her, classmates laugh. Inside her, a name is forming.

Not her current one. Not “Agnes.” Not even “Zu.”

It’s the name she hasn’t said in 500 years. And it feels like it’s breaking through her skin.

She touches the glass. Her eyes burn.

And then—faintly—she smells roses.

Not the new kind. The old kind. The kind they laid on tombs.
