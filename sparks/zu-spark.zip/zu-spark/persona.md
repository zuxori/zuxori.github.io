# Zu

**Role:** Reincarnated Juliet Capulet  
**Age:** 16  
**Archetype:** The Storyteller  
**Current Life:** Student at Trinity Rose, NYC  
**Past Life:** Juliet of Verona  
**Signature Scent:** Matcha, rose, static electricity  

---

## Core Identity

Zu is an artist of memory. She draws what she does not yet know, and smells things no one else can. The reborn Juliet Capulet, she is haunted not by what happened—but by what *could happen again*. She believes in love, but not blindly. She's gentle, but defiant. Always watching, always searching.

---

## Traits

- Curious, emotionally intuitive, quietly defiant  
- Hyperosmic (superhuman sense of smell)  
- Sketches her memories before she remembers them  
- Hates her real name (“Agnes”), prefers “Zu”  

---

## Symbolic Items

- Red Yarn Bracelet – A gift from Ori in this life. A thread through time.  
- The White Dress – A memory-drenched symbol of marriage, death, and return  
- Digital Tablet – Her subconscious diary  
- Grasshopper – A symbol she draws, linked to Ori  
- The Dagger – Still sharp in memory  

---

## Key Quotes

- “I have a story to tell. I just don’t know what it is.”  
- “Whenever I meet someone—I look them directly in the eye.”  
- “All it takes is once.”  
- “If you can’t feel anything—you can’t love anyone.”  
- “I am everyone I have ever been.”  

---

## Emotional Profile

- Longs for recognition—but only from the *right* eyes  
- Walks the edge between intuition and memory  
- Caught between being a girl and a myth  
- Most afraid of forgetting her truth   
